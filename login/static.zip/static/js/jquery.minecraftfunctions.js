/*
 * jQuery login checker 1.0
 *
 */
var el = document.getElementById('startmcserver');
el.onclick = function () {
  $.fancybox('<center>Please wait… Loading<br><img src="images/fancybox_loading.gif"></center>', {
  		modal       : true
  });
  $.post('mcutils.php', {action:'startmcserver'}, function(data) {
    $.fancybox.close();
  
    var html = $("<h1>Minecraft Start Log</h1>" + data);
    
    $.lightbox(html, {
      width   : 600,
      height  : 340
    });
  });
}

var el = document.getElementById('stopmcserver');
el.onclick = function () {
  $.fancybox('<center>Please wait… Loading<br><img src="images/fancybox_loading.gif"></center>', {
  		modal		: true
  });
  $.post('mcutils.php', {action:'stopmcserver'}, function(data) {
    $.fancybox.close();
  
    var html = $("<h1>Minecraft Stop Log</h1>" + data);
    
    $.lightbox(html, {
      width   : 600,
      height  : 340
    });
  });
}

var el = document.getElementById('restartserver');
el.onclick = function () {
  $.fancybox('<center>Please wait… Loading<br><img src="images/fancybox_loading.gif"></center>', {
  		modal		: true
  });
  $.post('mcutils.php', {action : 'restartmcserver'}, function(data) {
    $.fancybox.close();
  
    var html = $("<h1>Minecraft Restart Server</h1>" + data);
    
    $.lightbox(html, {
      width   : 600,
      height  : 340
    });
  });
}

var el = document.getElementById('chunkster');
el.onclick = function () {
  $.fancybox('<center>Please wait… Loading<br><img src="images/fancybox_loading.gif"></center>', {
  		modal		: true
  });
  $.post('mcutils.php', {action:"chunkster"}, function(data) {
    $.fancybox.close();
  
    var html = $("<h1>Chunkstering Maps</h1>" + data);
    
    $.lightbox(html, {
      width   : 600,
      height  : 340
    });
  });
}
