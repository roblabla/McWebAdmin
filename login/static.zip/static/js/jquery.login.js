/*
 * jQuery login checker 1.0
 *
 */
 
$(document).ready(function()
{
  $("#content-login .error").hide();
  $("#content-login .information").hide();

  $("#box-login").submit(function()
  {
    $.post("validateuser.php",{ user_name:$('#username').val(),password:$('#password').val(),rand:Math.random() } ,function(data)
    {
	  if(data=='yes')
	  {
            location.reload();
	  }
	  else 
	  {
	    if(data=='no')
	    {
              $().toastmessage('showErrorToast', "Login is incorrect...");
              $("#username").val("");
              $("#password").val("");
	    }
	    else
	    {
              alert("Login Error...");
	    }		
      }			
    });
    return false;
  });
});
